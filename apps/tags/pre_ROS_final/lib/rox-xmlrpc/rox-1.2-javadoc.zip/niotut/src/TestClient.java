import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;

public class TestClient {
	public static void main(String[] args) {
		try {
			Socket socket = new Socket("localhost", 9090);
			OutputStream os = socket.getOutputStream();
			os.write("Hello World".getBytes());
			InputStream is = socket.getInputStream();
			byte[] rsp = new byte[8192];
			int nRead = is.read(rsp);
			System.out.println("Response [" + new String(rsp, 0, nRead) + "]");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
